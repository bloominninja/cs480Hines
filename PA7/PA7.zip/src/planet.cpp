#ifndef PLANET_CPP_
#define PLANET_CPP_
#include "planet.h"

Planet::Planet()
    {
    
    }
    
Planet::~Planet()
    {
    	
    }
    
void Planet::GetPlanet(char* file) 
    {

    }

void Planet::UpdatePlanet() 
    {

    }

void Planet::UpdateMoons(char* file) 
    {

    }
#endif
