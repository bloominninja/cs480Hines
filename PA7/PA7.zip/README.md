Solar System
========================================

Building This Example
---------------------


To build this example cd to P7 directory, then

>$ cd build
>$ make

*If you are using a Mac you will need to edit the makefile in the build directory*

The excutable will be put in bin

To Run executable
navigate to bin
.$ ./SolarSystem 1


Additional Notes For OSX Users
------------------------------

Ensure that the latest version of the Developer Tools is installed.



Running This Example
---------------------

How 2 Use

Use the awesome power of the mouse button to right click on the screen

Start-Starts the simulation if stopped

Go to Planet- Cruises over to clicked on planets position

Put time in A bottle- Freeze the simulation

Toggle Scaled View- Toggle a more “visible” solar system

Quit-Exit the program


Extra Credit
---------------------
Toggleable Scaling
Transitioning Views
Solaire Reference

Known Bugs/fixes
---------------------
-Jumpy Transitions